
# This file is auto-generated with the version information during setup.py installation.
__version__ = '2.1.5'
