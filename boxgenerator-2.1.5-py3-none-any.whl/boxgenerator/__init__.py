"""BoxGene base."""
# yapf: disable
from boxgenerator.gen import (LireTransform,make,testing,testtensor)


version_prefix = "2.1.5"

# Get the __version__ string from the auto-generated _version.py file, if exists.
try:
    from doemini._version import __version__  # type: ignore
except ImportError:
    __version__ = version_prefix

# yapf: enable
__all__ = [
    '__version__',
    'LireTransform',
    'make',
    'testing',
    'testtensor'
]
